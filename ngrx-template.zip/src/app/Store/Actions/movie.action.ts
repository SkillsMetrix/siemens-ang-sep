import { createAction } from "@ngrx/store";
import { Movie } from "src/app/Models/movie";



export const getMovies = createAction('[loading the movie]')

export const getMoviesSuccess = createAction(
    '[Movie loaded successfully]',
    (movies: ReadonlyArray<Movie>) => ({ movies })
)

export const addMovie = createAction('[adding the movie]', (movie: Movie) => ({ movie }))

export const addMoviesSuccess = createAction(
    '[Movie added successfully]',
    (movie: Movie) => ({ movie })
)