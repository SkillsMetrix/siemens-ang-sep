import { Component, OnInit } from '@angular/core';
 import { Movie } from './Models/movie';
import { DataService } from './Service/data.service';
import { Store } from '@ngrx/store';
import { addMovie, getMovies } from './Store/Actions/movie.action';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  movies: Movie[] = [];
  newMovie: Movie = new Movie();
  title = 'movieApp';
  constructor(private store:Store) {}

  ngOnInit(): void {
    this.getAllMovies();
  }

  getAllMovies(): void {
    this.store.dispatch(getMovies())
  
  }

  addNewMovies(): void {
    this.store.dispatch(addMovie(this.newMovie))
   
  }
}
