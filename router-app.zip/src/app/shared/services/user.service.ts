import { Injectable } from "@angular/core";
import { User } from "../../models/User";
import { AppGuard } from "../guards/appguard";
import { Router } from "@angular/router";

@Injectable(
    {
        providedIn: 'root'
    }
)
export class UserService {

    constructor(private guard:AppGuard,private route:Router){}

    login(){
        this.guard.isAllowed=true
        this.route.navigateByUrl('/userdetails')
    }
    loadUsers(): string[] {
        return ['admin', 'manager', 'qa']
    }
    private users:User[] =
        [
            { id: 1, name: 'Amar', active: true },
            { id: 2, name: 'Sam', active: false },
            { id: 3, name: 'simar', active: true }
        ]
    getUsers() {
        return this.users
    }
}