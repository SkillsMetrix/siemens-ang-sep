import { Component, ViewChild } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';
import { AppGuard } from '../../shared/guards/appguard';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrl: './navigation.component.css'
})
export class NavigationComponent {
@ViewChild('sidenav')
   sideNav!: MatSidenav

 toogleSidenav(){
    this.sideNav.toggle()
   }
   constructor(public auth:AppGuard){}
   }
