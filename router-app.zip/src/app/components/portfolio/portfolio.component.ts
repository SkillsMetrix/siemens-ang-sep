import { Component } from '@angular/core';

@Component({
  selector: 'app-portfolio',
  templateUrl: './portfolio.component.html',
  styleUrl: './portfolio.component.css'
})
export class PortfolioComponent {

  links=[
    {path:'/portfolio/user', label: 'User',icon:'groups'},
      {path:'/portfolio/corporate', label: 'Corporate',icon:'terminal'},
      
   ]

}
