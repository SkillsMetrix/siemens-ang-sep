import { Component, ViewChild } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrl: './navigation.component.css'
})
export class NavigationComponent {
@ViewChild('sidenav')
   sideNav!: MatSidenav

   links=[
    {path:'/login', label: 'Login',icon:'home'},
      {path:'/register', label: 'Register',icon:'settings'},
        {path:'/userdetails', label: 'User Details',icon:'groups'},
          {path:'/portfolio', label: 'Portfolio',icon:'info'}
   ]

   toogleSidenav(){
    this.sideNav.toggle()
   }
   }
