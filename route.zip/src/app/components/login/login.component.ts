import { Component } from '@angular/core';
import { Validators } from '@angular/forms';
import { FormControl, FormGroup } from '@angular/forms';
 import { MatSnackBar } from '@angular/material/snack-bar';
 @Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
myForm!: FormGroup
  uname!: FormControl
  pass!: FormControl

  createForm() {
    this.myForm = new FormGroup({
      uname: this.uname,
      pass: this.pass,
    
    })
  }
  createFormControl() {
    this.uname = new FormControl('',[Validators.required])
    this.pass = new FormControl('')
   
  }
constructor(private sb:MatSnackBar){
  this.createFormControl()
  this.createForm()
}
login(){
    this.sb.open('Record Saved Successfully...!','close',{
    duration:3000,
    horizontalPosition: 'center',
    verticalPosition:'top',
    panelClass: ['success-snackbar']
    
    
   
  })
 console.log(this.myForm.value);
 
}


}
